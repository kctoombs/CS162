import scala.io._
import cs162.assign3.syntax._
import Aliases._
import scala.io.Source.fromFile

//—————————————————————————————————————————————————————————————————————————
// Main entry point

object Checker {
  type TypeEnv = scala.collection.immutable.HashMap[Var, Type]
  object Illtyped extends Exception

  var typeDefs = Set[TypeDef]()

  def main( args:Array[String] ) {
    val filename = args(0)
    val input = fromFile(filename).mkString
    Parsers.program.run(input, filename) match {
      case Left(e) => println(e)
      case Right(program) =>
        val prettied = Pretty.prettySyntax(program)
        typeDefs = program.typedefs

        try {
          getType( program.e, new TypeEnv())
          println(Pretty.prettySyntax(program))
          println("This program is well-typed:\n")
        } catch { case Illtyped => println("This program is ill-typed") }
    }
  }

  // Gets all the constructors associated with a given type name.
  // For example, consider the following typedefs:
  //
  // type Either = Left num | Right bool
  // type Maybe = Some num | None
  //
  // With respect to the above typedefs, `constructors` will return
  // the following underneath the given arguments:
  //
  // constructors(Label("Either")) = Map(Label("Left") -> NumT, Label("Right") -> BoolT)
  // constructors(Label("Maybe")) = Map(Label("Some") -> NumT, Label("None") -> UnitT)
  // constructors(Label("Fake")) throws Illtyped
  //
  def constructors(name: Label): Map[Label, Type] =
    typeDefs.find(_.name == name).map(_.constructors).getOrElse(throw Illtyped)

  // Gets the type of the constructor.
  // For example, considering the typedefs given in the `constructors` comment above,
  // `typename` will return the following with the given arguments:
  //
  // typename(Label("Left")) = Label("Either")
  // typename(Label("Right")) = Label("Either")
  // typename(Label("Some")) = Label("Maybe")
  // typename(Label("None")) = Label("Maybe")
  //
  def typename(constructor: Label): Label =
    typeDefs.find(_.constructors.contains(constructor)).getOrElse(throw Illtyped).name

  def getType( e:Exp, env:TypeEnv ): Type =
    e match {
      // variables
      case x:Var => ??? // FILL ME IN

      // numeric literals
      case _:Num => ??? // FILL ME IN

      // boolean literals
      case _:Bool => ??? // FILL ME IN

      // `nil` - the literal for unit
      case _: NilExp => ??? // FILL ME IN

      // builtin arithmetic operators
      case Plus | Minus | Times | Divide => ??? // FILL ME IN

      // builtin relational operators
      case LT | EQ => ??? // FILL ME IN

      // builtin logical operators
      case And | Or => ??? // FILL ME IN

      // builtin logical operators
      case Not => ??? // FILL ME IN

      // function creation
      case Fun(params, body) => ??? // FILL ME IN

      // function call
      case Call(fun, args) => ??? // FILL ME IN

      // conditionals 
      case If(e1, e2, e3) => ??? // FILL ME IN

      // let binding
      case Let(x, e1, e2) => ??? // FILL ME IN

      // recursive binding
      case Rec(x, t1, e1, e2) => ??? // FILL ME IN

      // record literals
      case Record(fields) => ??? // FILL ME IN

      // record access
      case Access(e, field) => ??? // FILL ME IN

      // constructor use
      case Construct(constructor, e) ⇒ ??? // FILL ME IN

      // pattern matching (case ... of ...)
      case Match(e, cases) => ??? // FILL ME IN
    }
}
